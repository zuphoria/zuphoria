﻿using System;

class Program
{
    static void Main()
    {
        Char y;
        string input = "";
        Console.WriteLine("write a name(more than two letters)");
        do
        {
            y = Console.ReadKey().KeyChar;

            if (char.IsLetter(y))
            {
                input += y;
            }
            else if (y != '\r')
            {
                Console.WriteLine("INCORRECT");

            }
        }
        while (y != '\r');
        {
            if (input.Length > 2)
            {
                Console.WriteLine("CORRECT");
            }
            else
            {
                Console.WriteLine("write a name with more than 2 letters");

            }
        }
    }
}
