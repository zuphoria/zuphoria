﻿using System;


class Program
{
    static void Main()
    {

        int n = 250;
        int m = 750;

        for (int j = n + 1; j < m; j++)

        {
            bool IsPrime = true;

            if (j < 2)

            {
                IsPrime = false;
            }
            else
            {
                for (int i = 2; i < j; i++)
                {
                    if (j % i == 0)

                        IsPrime = false;
                }
                if (IsPrime)
                {
                    Console.WriteLine(j + " Is Prime");
                }
                else
                {
                    Console.WriteLine(j + " Is not Prime");
                }
            }
        }
    }
}