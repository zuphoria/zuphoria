﻿using System;
using System.Diagnostics.Eventing.Reader;

class Program
{


    static void Main()
    {

        Console.WriteLine("do you want to shop here?");

        string answer = Console.ReadLine();


        if (answer == "yes" || answer == "Yes" || answer == "YES")
        {
            Console.WriteLine("do you want to buy Irainian products? ");
            answer = Console.ReadLine();
            if (answer == "yes" || answer == "Yes" || answer == "YES");

        }
        else if (answer == "no" || answer == "No" || answer == "NO")
        {
            Console.WriteLine(" do you want to sell in here?");
            answer = Console.ReadLine();
            if (answer == "yes" || answer == "Yes" || answer == "YES")
            {
                Console.WriteLine("your shop code is green code");
            }
            else
            {
                Console.WriteLine("your shop code is red code");
            }
        }
        else
            Console.WriteLine("Wrong Answer!!!!");
    }
}
