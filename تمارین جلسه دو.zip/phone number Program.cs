﻿using System;

class Program
{
    static void Main()
    {

        Console.Write("Enter a phone number: ");
        string phoneNumber = Console.ReadLine();

        if (IsValidPhoneNumber(phoneNumber))
        {
            Console.WriteLine("Number accepted.");
        }
        else
        {
            Console.WriteLine("Wrong Number.");
        }
    }

    static bool IsValidPhoneNumber(string number)
    {
        {
            if (number.Length != 10)
            {
                return false;
            }
            else if (number.Length == 10)
            {
                if (!HasAtLeastTwoDifferentDigits(number))
                {
                    return false;
                }
                else if (HasAtLeastTwoDifferentDigits(number))
                {
                    if (!number.Contains('0') && number.Contains('9'))
                    {
                        return false;
                    }
                    else if (number.Contains('0') && number.Contains('9'))
                    {
                        Console.WriteLine("phone number accepted");
                    }
                }
            }
        }

