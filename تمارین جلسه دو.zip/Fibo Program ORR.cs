﻿using System;

class Program
{
    static void Main()
    {
        Number();
    }

    static void Number()
    {
        Console.WriteLine("write a number");
        int n = int.Parse(Console.ReadLine());

        if (IsFibonacci(n))
        {
            Console.WriteLine("It is fibo");
        }
        else
        {
            Console.WriteLine("It is not fibo");
        }
    }

    static bool IsFibonacci(int n)
    {
        if (n == 0 || n == 1)
        {
            return true;
        }

        int a1 = 0;
        int a2 = 1;
        int next = a1 + a2;

        while (next <= n)
        {
            if (next == n)
            {
                return true;
            }
            a1 = a2;
            a2 = next;
            next = a1 + a2;
        }

        return false;
    }
}
