﻿using System;

class Program
{
    static void Main()
    {
        Char y;
        string input = "";
        Console.WriteLine("write a f number(more than three digits)");
        do
        {
            y = Console.ReadKey().KeyChar;

            if (char.IsDigit(y))
            {
                input += y;
            }
            else if (y != '\r')
            {
                Console.WriteLine("INCORRECT");

            }
        }
        while (y != '\r');
        {
            if (input.Length > 3)
            {
                Console.WriteLine("CORRECT");
            }
            else
            {
                Console.WriteLine("write a number with more than 3 digits");

            }
        }
    }
}
