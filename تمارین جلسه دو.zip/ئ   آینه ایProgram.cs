﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("write a number");

        string input = Console.ReadLine();

        if (IsPalindrome(input))
        {
            Console.WriteLine("{input} is ");
        }
        else
        {
            Console.WriteLine("{input} is not");
        }
    }

             static bool IsPalindrome(string number)
            {

                    int left = 0;
                    int right = number.Length - 1;

                  while (left < right)
                  {
                  if (number[left] != number[right])
                  {
                  return false;
                  }
                  right--;
                  left++;
                  }
                         return true;
                    }
                }
            
        

             